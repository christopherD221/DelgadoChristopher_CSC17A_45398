/* 
 * File:   main.cpp
 * Author: Christopher Delgado
 * Created on June 26th, 2021
 * Purpose: 
 */

//System Level Libraries
#include <iostream>   //I/O Library
using namespace std;  //Libraries compiled under std

//User Level Libraries

//Global Constants - Science/Math Related
//Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Random Number Seed Set Here
    
    //Variable Declarations
    
    //Variable Initialization
              
    //Mapping Process Inputs to Outputs
    
    
    //Display Outputs
    cout<<"Hello World";
    
    //Clean Up
    
    //Exit stage right!
    return 0;
}